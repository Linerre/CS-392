#ifndef CS392_LOG_H
#define CS392_LOG_H

#include <stdio.h>

void log_command(char *command);

#endif